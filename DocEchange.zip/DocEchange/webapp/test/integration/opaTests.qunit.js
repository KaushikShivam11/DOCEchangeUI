/* global QUnit */

sap.ui.require(["docexchangeui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
