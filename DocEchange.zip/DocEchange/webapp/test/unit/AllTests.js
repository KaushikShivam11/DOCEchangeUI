sap.ui.define([
	"docexchangeui/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
