/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "docexchangeui/model/models"
],
    function (UIComponent, Device, models) {
        "use strict";

        return UIComponent.extend("docexchangeui.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");

                this.findUserInfo();
            },

            findUserInfo: function(){
                new Promise(
                    function (resolve, reject) {
                      this.findANID(resolve, reject);
                    }.bind(this)
                  ).then(function (ANID) {
                    this.getUserDetailsBasedOnANID(ANID);
                  }.bind(this));
            },

            findANID: function (resolve, reject) {
                var sServiceUrl = this.getManifestObject().resolveUri('user-api/attributes');

                jQuery.ajax({
                    url: sServiceUrl,
                    method: "GET",
                    dataType: "json",
                    success: function (oData) {
                        if (oData.ANID[0]) {
                            resolve(oData);
                        }
                    }.bind(this),
                    error: function (oError) {
                        var oError = oError;
                        reject(oError);
                    }.bind(this)
                });
            },

            getUserDetailsBasedOnANID: function (ODATA) {
                var oModel = this.getModel(); // Assuming the ODataModel is already set on the view
                // var sPath = oModel.createKey("vendorMappingSet", {
                //     anId: ODATA.ANID[0],
                //     poNo: ''
                // });
                var sPath = "vendorMappingSet(anId='" + ODATA.ANID[0] + "',poNo='')";
                oModel.read("/" + sPath, {
                    success: function (oData) {
                        var userModel = new sap.ui.model.json.JSONModel();
                        this.setModel(userModel, "userModel");
                        if (oData.anId == 'AN11177191689-T') {
                            this.getModel("userModel").setData({
                                anId: "AN11177191689-T",
                                copySupplier: "",
                                poNo: "",
                                vendorMail: "prathamesh.mane@sap.com",
                                //vendorCode: "0000153593",
                                vendorCode: "0000153803",
                                vendorName: "SHREE JINDAL TRADING"
                            });
                        } else {
                            this.setModel("userModel").setData(oData);
                        }
                    }.bind(this),
                    error: function (oError) {
                        var oError = oError;
                    }
                });
            }
        });
    }
);