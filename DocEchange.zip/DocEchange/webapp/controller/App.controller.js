sap.ui.define(
  [
    "sap/ui/core/mvc/Controller"
  ],
  function (BaseController) {
    "use strict";

    return BaseController.extend("docexchangeui.controller.App", {
      onInit: function () {
        // new Promise(
        //   function (resolve, reject) {
        //     this.findANID(resolve, reject);
        //   }.bind(this)
        // ).then(function (ANID) {
        //   this.getUserDetailsBasedOnANID(ANID);
        // }.bind(this));

      },

      findANID: function (resolve, reject) {
        var sServiceUrl = this.getOwnerComponent().getManifestObject().resolveUri('user-api/attributes');

        jQuery.ajax({
          url: sServiceUrl,
          method: "GET",
          dataType: "json",
          success: function (oData) {
            if (oData.ANID[0]) {
              resolve(oData);
            }
          }.bind(this),
          error: function (oError) {
            var oError = oError;
            reject(oError);
          }.bind(this)
        });
      },

      getUserDetailsBasedOnANID: function (ODATA) {
        var oModel = this.getView().getModel(); // Assuming the ODataModel is already set on the view
        var sPath = oModel.createKey("vendorMappingSet", {
          anId: ODATA.ANID[0],
          poNo: ''
        });

        oModel.read("/" + sPath, {
          success: function (oData) {
            var userModel = new sap.ui.model.json.JSONModel();
            this.getOwnerComponent().setModel(userModel, "userModel");
            if (oData.anId == 'AN11177191689-T') {
              this.getOwnerComponent().getModel("userModel").setData({
                anId: "AN11177191689-T",
                copySupplier:"",
                poNo:"",
                vendorMail:"prathamesh.mane@sap.com",
                vendorCode :"0000153593",
                vendorName:"SHREE JINDAL TRADING"
              });
            }else {
              this.getOwnerComponent().setModel("userModel").setData(oData);
            }
          }.bind(this),
          error: function (oError) {
            var oError = oError;
          }
        });
      }
    });
  }
);
