sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/FileSizeFormat",
    "sap/ui/Device",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "sap/m/upload/UploadSetItem",
    "sap/ui/core/Item",
    "sap/m/MessageBox",
    "sap/ui/core/UIComponent",
    "sap/ui/core/Fragment",
    "sap/m/Token",
    "sap/ui/core/CustomData",
    "../model/formatter"
], function (Controller, JSONModel, FileSizeFormat, Device, Filter, FilterOperator,
    History, MessageToast, UploadSetItem, Item, MessageBox, UIComponent, Fragment, Token, CustomData, formatter) {
    "use strict";
    return Controller.extend("docexchangeui.controller.Detail", {
        formatter: formatter,
        onInit: function () {
            this.getRouter().getRoute("Detail").attachPatternMatched(this._onObjectMatched, this);
        },

        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },

        _onObjectMatched: function (oEvent) {
            var oDetailModel = new JSONModel();
            this.getView().setModel(oDetailModel, "detailModel");
            var oInvoiceModel = new JSONModel();
            this.getView().setModel(oInvoiceModel, "invoiceModel");
            var oSelectionItemsModel = new JSONModel({ FinalItemModel: [] });
            this.getView().setModel(oSelectionItemsModel, "SelectionItemModel");
            var oSelectedItemsModel = new JSONModel({ FinalItemModel: [] });
            this.getView().setModel(oSelectedItemsModel, "selectedItemsModel");
            var oAttachment = new JSONModel();
            this.getView().setModel(oAttachment, "Attachments");
            var oRestDocModel = new JSONModel();
            this.getView().setModel(oRestDocModel, "restDocModel");
            var oWorkflowReadinessDocModel = new JSONModel();
            this.getView().setModel(oWorkflowReadinessDocModel, "workflowReadinessDocModel");
            var oWorkflowCompletionDocModel = new JSONModel();
            this.getView().setModel(oWorkflowCompletionDocModel, "workflowCompletionDocModel");
            var oScreenModel = new JSONModel({
                "display": ""
            });
            this.getView().setModel(oScreenModel, "screenTypeModel");
            var oWorkflowCompletionFileModel = new JSONModel();
            this.getView().setModel(oWorkflowCompletionFileModel, "workflowCompletionFileModel");
            var oWorkflowFileModel = new JSONModel();
            this.getView().setModel(oWorkflowFileModel, "workflowFileModel");
            var oFileModel = new JSONModel();
            this.getView().setModel(oFileModel, "fileModel");
            this.sPoNo = oEvent.getParameter("arguments").PoNo;
            var sScreenType = oEvent.getParameter("arguments").screenType;
            this.getView().getModel("screenTypeModel").setProperty("/display", sScreenType);
            var oModel = this.getView().getModel();
            var oRestModel = this.getView().getModel("rest");
            var sDocPath = jQuery.sap.getModulePath("docexchangeui","/model/docList.JSON");
            var sVendorNo = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
            var oDocListData = {
                "DocList": [{
                    "title": "BL Copy",
                    "completed": false
                },
                {
                    "title": "Invoice Copy",
                    "completed": false
                },
                {
                    "title": "BOE Copy",
                    "completed": false
                },
                {
                    "title": "CP Copy",
                    "completed": false
                },
                {
                    "title": "Contract Copy",
                    "completed": false
                },
                {
                    "title": "Form 10F",
                    "completed": false
                },
                {
                    "title": "TRC",
                    "completed": false
                },
                {
                    "title": "No PE Certificate",
                    "completed": false
                },
                {
                    "title": "Others Copy",
                    "completed": false
                }
                ],
                "completedCount": 1
            };
            var oDocListModel = new JSONModel(oDocListData);
            this.getView().setModel(oDocListModel, "docListModel");
            var sPath = oModel.createKey("PODetailsSet", {
                orderNumber: this.sPoNo,
                vendorNo: sVendorNo
            });
            oModel.read("/" + sPath, {
                success: function (oData) {
                    this.getView().getModel("detailModel").setData(oData);
                    // // Create a JSONModel with the item data
                    // var oPOItemModel = new JSONModel({ FinalItemModel: oData.POLineItemsSet.results });
                    // // Set the item data model to the view table 1
                    // this.getView().setModel(oPOItemModel, "SelectionItemModel");
                    this.getView().getModel("SelectionItemModel").setData({ FinalItemModel: oData.POLineItemsSet.results });

                }.bind(this),
                error: function (oError) {

                }.bind(this),
                urlParameters: {
                    $expand: 'POLineItemsSet,POVendorsSet,partnerFunctionsSet'
                }
            });
            if (sScreenType === 'InvoiceDetail') {
                var sInvNo = oEvent.getParameter("arguments").InvoiceNo;
                var sRegID = oEvent.getParameter("arguments").RegID;
                this._readInvoiceData(sInvNo, sRegID);
            }
            this._readExhangeDocuments();
            this._readWorkflowReadinessDocuments();
            this._readWorkflowCompletionDocuments();
        },

        _readInvoiceData: function (sInvNo, sRegID) {
            var oInvoiceOdataModel = this.getView().getModel("ZMM_INVOICE_SRV")
            var sKey = oInvoiceOdataModel.createKey("/InvoiceRequestSet", {
                PoNumber: this.sPoNo,
                regID: sRegID,
                invoiceNo: sInvNo
            });
            this.getView().setBusy(true);
            oInvoiceOdataModel.read(sKey, {
                urlParameters: {
                    $expand: 'InvoiceAttachmentSet,InvoiceLineItemSet'
                },
                success: function (oData) {
                    var aAttachments = oData.InvoiceAttachmentSet.results.map(function (curr) {
                        return {
                            Name: curr.Name,
                            MediaType: curr.filetype,
                            attachmentNo: curr.attachmentNo,
                            PoNumber: curr.PoNumber,
                            url: "/sap/opu/odata/sap/ZMM_INVOICE_SRV/invoiceAttachSet('" + curr.attachmentNo + "')/$value"
                        }
                    }.bind(this));
                    this.getView().getModel("Attachments").setData(aAttachments);
                    this.getView().getModel("invoiceModel").setData(oData);
                    this.getView().getModel("selectedItemsModel").setData({ FinalItemModel: oData.InvoiceLineItemSet.results });
                    this.getView().setBusy(false);
                }.bind(this),
                error: function (oErr) {
                    this.getView().setBusy(false);
                    var oErr = oErr;
                }.bind(this)
            });
        },

        _readExhangeDocuments: function (oRestModel, oPoFilter) {
            var oRestModel = this.getView().getModel("rest");
            var oPoFilter = new Filter("poNumber", FilterOperator.EQ, this.sPoNo);
            var oVendorFilter = new Filter("vendorEmail", FilterOperator.EQ, this.sPoNo);
            //oRestModel.setDeferredGroups(["myGroupId"]);
            oRestModel.read("/ExchangeDocuments", {
                //groupId: "myGroupId",
                filters: [oPoFilter],
                success: function (oData) {
                    this.getView().getModel("restDocModel").setData(oData);
                    this.getView().getModel("restDocModel").setProperty("/sRestResolvedUrl", this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/downloadData/"));
                }.bind(this),
                error: function (oErr) {
                    var oErr = oErr;
                }.bind(this),
                urlParameters: {
                    $expand: "recipients/vendor,comments"
                }
            });


        },

        _readWorkflowReadinessDocuments: function () {
            var oRestModel = this.getView().getModel("rest");
            var oPoFilter = new Filter("poNumber", FilterOperator.EQ, this.sPoNo);
            var oVendorFilter = new Filter("vendorCode", FilterOperator.EQ, this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode"));
            var oWorkflowTypeFilter = new Filter("workflowType", FilterOperator.EQ, "materialRediness");
            oRestModel.read("/WorkflowDocument", {
                //groupId: "myGroupId",
                filters: [oPoFilter, oWorkflowTypeFilter, oVendorFilter],
                success: function (oData) {
                    this.getView().getModel("workflowReadinessDocModel").setData(oData);
                    this.getView().getModel("workflowReadinessDocModel").setProperty("/sRestResolvedUrl", this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/downloadData/"));
                }.bind(this),
                error: function (oErr) {
                    var oErr = oErr;
                }.bind(this)
            });
        },

        _readWorkflowCompletionDocuments: function () {
            var oRestModel = this.getView().getModel("rest");
            var oPoFilter = new Filter("poNumber", FilterOperator.EQ, this.sPoNo);
            var oVendorFilter = new Filter("vendorCode", FilterOperator.EQ, this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode"));
            var oWorkflowTypeFilter = new Filter("workflowType", FilterOperator.EQ, "workflowCompletion");
            oRestModel.read("/WorkflowDocument", {
                //groupId: "myGroupId",
                filters: [oPoFilter, oWorkflowTypeFilter, oVendorFilter],
                success: function (oData) {
                    this.getView().getModel("workflowCompletionDocModel").setData(oData);
                    this.getView().getModel("workflowCompletionDocModel").setProperty("/sRestResolvedUrl", this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/downloadData/"));
                }.bind(this),
                error: function (oErr) {
                    var oErr = oErr;
                }.bind(this)
            });
        },

        onCreateInvoice : function(){
            this.getRouter().navTo("CreateInvoice", {
                PoNo: this.sPoNo
            });
        },

        onInvoiceValueChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onInvoiceNumberChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onInvoiceDateChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onSelectionChange: function (oEvent) {
            var oTable = oEvent.getSource();
            var aSelectedItems = oTable.getSelectedItems();
            var aSelectedContexts = aSelectedItems.map(function (item) {

                var i = item.getBindingContext("SelectionItemModel").getObject();
                i.OrginalQty = Number(i.lineItemQuant);
                return i;
            });


            // Update the selectedItemsModel with the selected items

            aSelectedContexts.forEach(item => {

                if (!item.TotalValue) { // Convert unitPrice and lineItemQuant to numbers and multiply
                    let amount = parseFloat(item.unitPrice.trim()) * parseFloat(item.lineItemQuant.trim());
                    // Assign the calculated amount to the TotalValue field
                    item.lineItemQuant = Number(item.lineItemQuant.trim())
                    item.TotalValue = amount.toString();

                    item.cgstValue = parseFloat((parseFloat(amount.toString()) * (parseFloat(item.CgstPercent) / 100)).toFixed(4));
                    item.sgstValue = parseFloat((parseFloat(amount.toString()) * (parseFloat(item.sgstPercent) / 100)).toFixed(4));

                }

            });


            this.getView().getModel("selectedItemsModel").setData({ FinalItemModel: aSelectedContexts });
            this.calculateOverallTotal();
        },

        onQuantityChange: function (oEvent) { // Get the event source which is the input field
            var oInput = oEvent.getSource();
            // Get the current row context
            var oContext = oInput.getBindingContext("selectedItemsModel");
            // Retrieve the new quantity value entered by the user and original quantity
            var iNewQuantity = parseInt(oInput.getValue(), 10);
            // Validate the new quantity
            if (isNaN(iNewQuantity) || iNewQuantity <= 0 || iNewQuantity > oContext.getProperty("OrginalQty") || iNewQuantity.toString() !== oInput.getValue()) { // If validation fails, set input field to Error state and return
                oInput.setValueState(sap.ui.core.ValueState.Error);
                oInput.setValueStateText("Invalid quantity. Must be a positive integer and cannot exceed original quantity.");
                this.getModel("objectView").setProperty("/enabled", false);
                return;
            } else { // If validation passes, reset input field state to None
                oInput.setValueState(sap.ui.core.ValueState.None);
                //this.getModel("objectView").setProperty("/enabled", true);
                // Proceed with total value calculation since validation passed
                var fUnitPrice = parseFloat(oContext.getProperty("unitPrice"));
                var fNewTotalValue = parseFloat((iNewQuantity * fUnitPrice).toFixed(4));
                let cgstValue = parseFloat((parseFloat(fNewTotalValue) * (parseFloat(oContext.getProperty("CgstPercent")) / 100)).toFixed(2));
                let sgstValue = parseFloat((parseFloat(fNewTotalValue) * (parseFloat(oContext.getProperty("sgstPercent")) / 100)).toFixed(2));


                // Update the model with the new total value,cgst,sgst values
                oContext.getModel().setProperty(oContext.getPath() + "/TotalValue", fNewTotalValue.toString());
                oContext.getModel().setProperty(oContext.getPath() + "/cgstValue", cgstValue);
                oContext.getModel().setProperty(oContext.getPath() + "/sgstValue", sgstValue);

                this.calculateOverallTotal();
            }


        },

        calculateOverallTotal: function () {
            var oModel = this.getView().getModel("selectedItemsModel");
            var aLineItems = oModel.getProperty("/FinalItemModel");

            // Initialize total values
            var fOverallTotal = 0,
                fOverallTotalCGST = 0,
                fOverallTotalSGST = 0;

            // Use a single loop to calculate totals
            aLineItems.forEach(function (currentItem) { // Calculate TotalValue
                var fTotalValue = parseFloat(currentItem.TotalValue);
                if (isNaN(fTotalValue)) {
                    fTotalValue = 0;
                }
                fOverallTotal += fTotalValue;

                // Calculate CGST
                var fTotalValueCGST = parseFloat(currentItem.cgstValue);
                if (isNaN(fTotalValueCGST)) {
                    fTotalValueCGST = 0;
                }
                fOverallTotalCGST += fTotalValueCGST;

                // Calculate SGST
                var fTotalValueSGST = parseFloat(currentItem.sgstValue);
                if (isNaN(fTotalValueSGST)) {
                    fTotalValueSGST = 0;
                }
                fOverallTotalSGST += fTotalValueSGST;
            });

            // Calculate Grand Total
            let GrandTotal = parseFloat((fOverallTotal + fOverallTotalCGST + fOverallTotalSGST).toFixed(4));


            // Set the calculated totals in the model
            var CalculatedTotalModel = new JSONModel({ total: fOverallTotal, total_cgst: fOverallTotalCGST, total_sgst: fOverallTotalSGST, Grand_total: GrandTotal });
            this.getView().setModel(CalculatedTotalModel, "TotalCostDataModel");


            // console.log("Overall Total:", fOverallTotal);
            this.setAmtInputState(GrandTotal, "ITM");
            return fOverallTotal;
        },

        setAmtInputState: function (Amt, From) {
            var HeaderAmount;
            var ItemAmount;
            if (HeaderAmount > ItemAmount || HeaderAmount <= 0) {
                this.getView().byId("AdvPayValue").setValueState(sap.ui.core.ValueState.Error);
                this.getView().byId("AdvPayValue").setValueStateText("Header amount can't be greater then Item Level Amount or (Zero/Empty) to any negative.");
                this.getModel("objectView").setProperty("/enabled", false);
            } else {
                this.getModel("objectView").setProperty("/enabled", true);
            }
        },

        onAfterWorkflowCompletionItemAdded: function (oEvent) {
            var oFileData = {
                FileIcon: oEvent.getParameter("item")._getIcon().getProperty("src"),
                FileName: oEvent.getParameter("item").getFileName()
            }
            this.oWorkflowDocFile = oEvent.getParameter("item").getFileObject();
            this.openWorkflowCompletionAttachmentDialog();
            this.getView().getModel("workflowCompletionFileModel").setData(oFileData);
        },

        onAfterWorkflowItemAdded: function (oEvent) {
            var oFileData = {
                FileIcon: oEvent.getParameter("item")._getIcon().getProperty("src"),
                FileName: oEvent.getParameter("item").getFileName()
            }
            this.oWorkflowDocFile = oEvent.getParameter("item").getFileObject();
            this.openWorkflowAttachmentDialog();
            this.getView().getModel("workflowFileModel").setData(oFileData);
        },

        onAfterItemAdded: function (oEvent) {
            var oFileData = {
                FileIcon: oEvent.getParameter("item")._getIcon().getProperty("src"),
                FileName: oEvent.getParameter("item").getFileName()
            }
            this.getView().setBusy(true);
            this._fnUplaodFile(oEvent.getParameter("item").getFileObject(), "").then(function (docStorageId) {
                this.getView().setBusy(false);
                this.openAttachmentDialog(docStorageId, false);
            }.bind(this));
            this.getView().getModel("fileModel").setData(oFileData);
        },

        onUploadComplted: function (oEvent) {
            var oUploadSet = oEvent.getSource();
            oUploadSet.setUploadUrl(null);
        },

        onSelect: function (oEvent) {
            var oItem = oEvent.getParameter("items");
        },

        openWorkflowAttachmentDialog: function () {
            if (!this._oWorkflowAttachmentDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.addWorkflowAttachment",
                    controller: this
                }).then(function (_oWorkflowAttachmentDialog) {
                    this._oWorkflowAttachmentDialog = _oWorkflowAttachmentDialog;
                    this.getView().addDependent(this._oWorkflowAttachmentDialog);
                    this._oWorkflowAttachmentDialog.open();
                }.bind(this));
            } else {
                this._oWorkflowAttachmentDialog.open();
            }
        },

        openWorkflowCompletionAttachmentDialog: function () {
            if (!this._oWorkflowCompletionAttachmentDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.addWorkflowCompletionAttachment",
                    controller: this
                }).then(function (_oWorkflowCompletionAttachmentDialog) {
                    this._oWorkflowCompletionAttachmentDialog = _oWorkflowCompletionAttachmentDialog;
                    this.getView().addDependent(this._oWorkflowCompletionAttachmentDialog);
                    this._oWorkflowCompletionAttachmentDialog.open();
                }.bind(this));
            } else {
                this._oWorkflowCompletionAttachmentDialog.open();
            }
        },

        openAttachmentDialog: function (docStorageId, bFlag) {
            this.docStorageId = docStorageId;
            if (!this._oAttachmentDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.addAttachment",
                    controller: this
                }).then(function (_oAttachmentDialog) {
                    this._oAttachmentDialog = _oAttachmentDialog;
                    this.getView().addDependent(this._oAttachmentDialog);
                    sap.ui.getCore().byId("idSupListBox").setVisible(bFlag);
                    sap.ui.getCore().byId("idSupForm").setVisible(!bFlag);
                    sap.ui.getCore().byId("idComments").setValue("");
                    this._oAttachmentDialog.open();
                }.bind(this));
            } else {
                sap.ui.getCore().byId("idSupListBox").setVisible(bFlag);
                sap.ui.getCore().byId("idSupForm").setVisible(!bFlag);
                sap.ui.getCore().byId("idComments").setValue("");
                this._oAttachmentDialog.open();
            }
        },

        onClose: function () {
            this._oAttachmentDialog.close();
        },

        onEditSup: function () {
            var oItem = this.getView().byId("UploadSet").getSelectedItem();
            if (oItem) {
                var oItemObject = oItem[0].getBindingContext("restDocModel").getObject();
                var sItemPath = oItem[0].getBindingContext("restDocModel").getPath();
                var oFileData = {
                    FileIcon: oItem[0]._getIcon().getProperty("src"),
                    FileName: oItemObject.docName,
                    FromVendor: oItemObject.fromVendor,
                    CreatedAt: oItemObject.createdAt
                }
                this.getView().getModel("fileModel").setData(oFileData);
                this.openAttachmentDialog(oItemObject.DocStorageId, true);
                var aVendors = this.getView().getModel("restDocModel").getProperty(sItemPath + "/recipients/results");
                var aComments = this.getView().getModel("restDocModel").getProperty(sItemPath + "/comments/results");
                this.getView().getModel("restDocModel").setProperty("/aVendors", aVendors);
                this.getView().getModel("restDocModel").setProperty("/aComments", aComments);
            } else {
                MessageBox.information("Please Select the Document from the Document Exchange List");
            }
        },

        onClickSupplierValueList: function () {
            if (!this._oSupplierDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.SupplierList",
                    controller: this
                }).then(function (_oSupplierDialog) {
                    this._oSupplierDialog = _oSupplierDialog;
                    this.getView().addDependent(this._oSupplierDialog);
                    this._oSupplierDialog.open();
                }.bind(this));
            } else {
                this._oSupplierDialog.open();
            }
        },

        handleSuppliersValueHelpClose: function (oEvent) {
            var aSelectedItems = oEvent.getParameter("selectedItems");
            var aTokens = aSelectedItems.map(function (curr) {
                var oToken = new Token({
                    text: curr.getBindingContext("detailModel").getObject().email
                });

                var oCustomData = new CustomData({
                    customData: [
                        {
                            key: "vendorNo",
                            value: curr.getBindingContext("detailModel").getObject().vendorNo
                        },
                        {
                            key: "firstName",
                            value: curr.getBindingContext("detailModel").getObject().firstname
                        }
                    ]
                });
                oToken.addCustomData(oCustomData);
                return oToken;
            });

            sap.ui.getCore().byId("idSupplierMultiInput").setTokens(aTokens);
        },

        _fnUplaodFile: function (file, description) {
            var formData = new FormData();
            formData.append("fileUploader", file);
            formData.append("description", description);
            formData.append("type", file.type);
            formData.append("vendorCode", '1234');
            formData.append("poNumber", this.getView().getModel("detailModel").getProperty("/orderNumber"));
            /* eslint-enable */
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    url: this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/upload"),
                    success: function (oData, textStatus, jqXHR) {
                        this.getView().byId("UploadSet").destroyIncompleteItems();
                        resolve(oData.docStorageId);
                    }.bind(this),
                    error: function (oError) {
                        reject(oData.docStorageId);
                    }
                });
            }.bind(this));
        },

        onWorkflowReadinessDocSubmit: function () {
            var formData = new FormData();
            formData.append("fileUploader", this.oWorkflowDocFile);
            formData.append("description", '');
            formData.append("docType", this.oWorkflowDocFile.type);
            formData.append("approverName", sap.ui.getCore().byId("idWorkflowName").getValue());
            formData.append("approverEmail", sap.ui.getCore().byId("idWorkflowEmail").getValue());
            formData.append("workflowType", "materialRediness");
            formData.append("vendorName", this.getOwnerComponent().getModel("userModel").getProperty("/vendorName"));
            formData.append("vendorEmail", this.getOwnerComponent().getModel("userModel").getProperty("/vendorMail"));
            formData.append("vendorCode", this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode"));
            formData.append("poNumber", this.getView().getModel("detailModel").getProperty("/orderNumber"));
            this.getView().setBusy(true);
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    url: this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/triggerWorkflow"),
                    success: function (oData, textStatus, jqXHR) {
                        this._readWorkflowReadinessDocuments();
                        this.getView().byId("idWorkflowUploadSet").destroyIncompleteItems();
                        this._oWorkflowAttachmentDialog.close();
                        this.getView().setBusy(false);
                        resolve(oData.docStorageId);
                    }.bind(this),
                    error: function (oError) {
                        this.getView().setBusy(false);
                        this.getView().byId("idWorkflowUploadSet").destroyIncompleteItems();
                        this._oWorkflowAttachmentDialog.close();
                        MessageBox.error("");
                        reject(oError);
                    }.bind(this)
                });
            }.bind(this));
        },

        onWorkflowReadinessDocClose: function () {
            this._oWorkflowAttachmentDialog.close();
        },

        onWorkflowCompletionDocSubmit: function () {
            var formData = new FormData();
            formData.append("fileUploader", this.oWorkflowDocFile);
            formData.append("description", '');
            formData.append("docType", this.oWorkflowDocFile.type);
            formData.append("approverName", sap.ui.getCore().byId("idWorkflowCompletionName").getValue());
            formData.append("approverEmail", sap.ui.getCore().byId("idWorkflowCompletionEmail").getValue());
            formData.append("workflowType", "workflowCompletion");
            formData.append("vendorName", this.getOwnerComponent().getModel("userModel").getProperty("/vendorName"));
            formData.append("vendorEmail", this.getOwnerComponent().getModel("userModel").getProperty("/vendorMail"));
            formData.append("vendorCode", this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode"));
            formData.append("poNumber", this.getView().getModel("detailModel").getProperty("/orderNumber"));
            this.getView().setBusy(true);
            return new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    url: this.getOwnerComponent().getManifestObject().resolveUri("aribaedockit/rest/triggerWorkflow"),
                    success: function (oData, textStatus, jqXHR) {
                        this._readWorkflowCompletionDocuments();
                        this.getView().byId("idWorkflowCompletionUploadSet").destroyIncompleteItems();
                        this._oWorkflowCompletionAttachmentDialog.close();
                        this.getView().setBusy(false);
                        resolve(oData.docStorageId);
                    }.bind(this),
                    error: function (oError) {
                        this.getView().setBusy(false);
                        this.getView().byId("idWorkflowCompletionUploadSet").destroyIncompleteItems();
                        this._oWorkflowCompletionAttachmentDialog.close();
                        MessageBox.error("");
                        reject(oError);
                    }.bind(this)
                });
            }.bind(this));
        },

        onWorkflowCompletionsDocClose: function () {
            this._oWorkflowCompletionAttachmentDialog.close();
        },

        onSubmit: function () {
            this.getView().setBusy(true);
            var oDocStorageObject = {},
                oDocComments = {},
                aSelectedSup = sap.ui.getCore().byId("idSupMultiComboBox").getSelectedItems(),
                aSupplierData = aSelectedSup.map(function (curr) {
                    return {
                        "email": curr.getKey(),
                        "vendorCode": curr.data().vendor,
                        "name": curr.data().name
                    }
                });
            oDocStorageObject.docStorageId = this.docStorageId;
            oDocStorageObject.recipients = aSupplierData;
            new Promise(function (resolve, reject) {
                jQuery.ajax({
                    type: "POST",
                    data: JSON.stringify(oDocStorageObject),
                    processData: false,
                    dataType: 'json',
                    contentType: 'application/json',
                    url: this.getOwnerComponent().getManifestObject().resolveUri("rest/exchangeDocument"),
                    success: function (oData, textStatus, jqXHR) {
                        resolve(oData);
                    }.bind(this),
                    error: function (oError) {
                        reject(oData);
                    }
                });
            }.bind(this)).then(
                function () {
                    var sComments = sap.ui.getCore().byId("idComments").getValue();
                    if (sComments) {
                        oDocComments.Text = sComments;
                        oDocComments.vendorCode = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
                        oDocComments.DocumentDetail_DocStorageId = this.docStorageId;
                        oDocComments.fromEmail = this.getOwnerComponent().getModel("userModel").getProperty("/vendorName");
                        var oRestModel = this.getView().getModel("rest");
                        oRestModel.create("/DocumentComments", oDocComments, {
                            success: function (oRes) {
                                this._readExhangeDocuments();
                                this._oAttachmentDialog.close();
                                this.getView().getModel("rest").refresh();
                                this.getView().setBusy(false);
                            }.bind(this),
                            error: function (oErr) {
                                var oErr = oErr;
                            }
                        })
                    } else {
                        this._readExhangeDocuments();
                        this._oAttachmentDialog.close();
                        this.getView().getModel("rest").refresh();
                        this.getView().setBusy(false);
                    }
                }.bind(this)
            )
        },

        onDisplaySupList: function () {
            sap.ui.getCore().byId("idSupForm").setVisible(false);
            sap.ui.getCore().byId("idSupListBox").setVisible(true);
        },

        onDisplaySupForm: function () {
            var aAssignedSup = sap.ui.getCore().byId("idSupList").getItems();
            var aAssignedSupEmail = aAssignedSup.map(function (curr) {
                return curr.getBindingContext("restDocModel").getObject().vendor.email;
            }.bind(this));
            sap.ui.getCore().byId("idSupMultiComboBox").setSelectedKeys(aAssignedSupEmail);
            sap.ui.getCore().byId("idSupForm").setVisible(true);
            sap.ui.getCore().byId("idSupListBox").setVisible(false);
        },

        onBeforeUploadStarts: function () {
            if (!this._oDocListDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.documentList",
                    controller: this
                }).then(function (_oDocListDialog) {
                    this._oDocListDialog = _oDocListDialog;
                    this.getView().addDependent(this._oDocListDialog);
                    this._oDocListDialog.open();
                }.bind(this));
            } else {
                this._oDocListDialog.open();
            }
        },

        onCloseDocListDialog: function () {
            this._oDocListDialog.close();
        },

        onDocListPress: function () {
            if (!this._oDocListDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.documentList",
                    controller: this
                }).then(function (_oDocListDialog) {
                    this._oDocListDialog = _oDocListDialog;
                    this.getView().addDependent(this._oDocListDialog);
                    this._oDocListDialog.open();
                }.bind(this));
            } else {
                this._oDocListDialog.open();
            }
        },

        onSubmitInvoice: function () {
            this.getView().setBusy(true);
            var aInvoiceLineItems = this.getView().byId("idPRItem2Table").getItems();
            if (!this.getView().byId("idInvoiceNumberInput").getValue()) {
                MessageBox.error("Please enter the Invoice Number");
                this.getView().byId("idInvoiceNumberInput").setValueState("Error");
                this.getView().byId("idInvoiceNumberInput").setValueStateText("Please enter the Invoice Number");
                return;
            }
            if (!this.getView().byId("idInvoiceValue").getValue()) {
                MessageBox.error("Please enter the Invoice Value");
                this.getView().byId("idInvoiceValue").setValueState("Error");
                this.getView().byId("idInvoiceValue").setValueStateText("Please enter the Invoice Value");
                return;
            }
            if (!this.getView().byId("idInvoiceDate").getValue()) {
                MessageBox.error("Please select the Invoice Date");
                this.getView().byId("idInvoiceDate").setValueState("Error");
                this.getView().byId("idInvoiceDate").setValueStateText("Please select the Invoice Date");
                return;
            }
            var aIncompleteFiles = this.getView().byId("idAttachments").getIncompleteItems();
            if (aInvoiceLineItems.length === 0) {
                MessageBox.error("Please select the Items from PO Table");
                return;
            }
            var iPointer = 1;
            Promise.all(
                aIncompleteFiles.map(function (curr) {
                    return new Promise(function (resolve, reject) {
                        const fileReader = new FileReader();

                        fileReader.onload = function (file) {
                            var ofileObject = {
                                "attachment": file.target.result.split(',')[1],
                                "Name": curr.getFileObject().name,
                                "PoNumber": this.sPoNo,
                                "filetype": curr.getFileObject().type,
                                "attachmentNo": (iPointer++).toString()
                            }
                            resolve(ofileObject);
                        }.bind(this);

                        fileReader.onerror = (error) => reject(error);

                        fileReader.readAsDataURL(curr.getFileObject());
                    }.bind(this));
                }.bind(this))
            ).then(function (base64Files) {
                var aBase64Files = base64Files;
                var oDetailModelData = this.getView().getModel("detailModel").getData();
                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyyMMdd" });
                var oDateNonFormatted = this.getView().byId("idInvoiceDate").getDateValue();
                var sDateFormatted = oDateFormat.format(oDateNonFormatted);
                var oInvoicePayload = {
                    "PoNumber": this.sPoNo,
                    "contractNumber": oDetailModelData.contractNo,
                    "VendorName": oDetailModelData.vendorName,
                    "VendorGSTIN": oDetailModelData.vendorGstin,
                    "invoiceNo": this.getView().byId("idInvoiceNumberInput").getValue(),
                    "invoiceDate": sDateFormatted,
                    "invoiceValue": this.getView().byId("idInvoiceValue").getValue(),
                    "curr": oDetailModelData.curr,
                    "email": oDetailModelData.email,
                    "supplierNo": this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode")
                }
                oInvoicePayload.InvoiceAttachmentSet = aBase64Files;
                var aInvoiceLineItemsPaylod = aInvoiceLineItems.map(function(curr) {
                    var oBindingContext = curr.getBindingContext("selectedItemsModel").getObject();
                    var oInvoiceLineItemsPaylod =
                    {
                        "itemNo": oBindingContext.itemNo,
                        "itemDesc": oBindingContext.itemDesc,
                        "itemCondDesc": oBindingContext.itemCondDesc,
                        "plant": oBindingContext.plant,
                        "lineItemQuant": oBindingContext.lineItemQuant.toString(),
                        "unitPrice": oBindingContext.unitPrice,
                        "TotalValue": oBindingContext.TotalValue,
                        "CgstPercent": oBindingContext.CgstPercent,
                        "sgstPercent": oBindingContext.sgstPercent,
                        "cgstValue": oBindingContext.cgstValue.toString(),
                        "sgstValue": oBindingContext.sgstValue.toString(),
                        "orderNumber": oBindingContext.orderNumber,
                        "condType" : oBindingContext.condType,
                        "amount" : oBindingContext.amount,
                        "conditionValue" : oBindingContext.conditionValue
                    }
                    return oInvoiceLineItemsPaylod;
                }.bind(this));

                oInvoicePayload.InvoiceLineItemSet = aInvoiceLineItemsPaylod;
                this.getView().getModel("ZMM_INVOICE_SRV").create("/InvoiceRequestSet", oInvoicePayload, {
                    success: function (oData, oRes) {
                        var sMsg = `Invoice Created with Reg ID ${oData.regID}`
                        MessageBox.success(sMsg);
                        this.getView().byId("idAttachments").destroyIncompleteItems();
                        this.getView().byId("idInvoiceNumberInput").setValue("");
                        this.getView().byId("idInvoiceValue").setValue("");
                        this.getView().byId("idInvoiceDate").setValue("");
                        this.getView().setBusy(false);
                    }.bind(this),
                    error: function (oErr) {
                        var oErr = oErr;
                        this.getView().byId("idAttachments").destroyIncompleteItems();
                        this.getView().setBusy(false);
                        MessageBox.error("");
                    }
                });

            }.bind(this));


        }

    });

});
