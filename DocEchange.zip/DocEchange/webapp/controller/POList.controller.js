sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    'sap/ui/comp/smartvariants/PersonalizableInfo'
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, UIComponent, JSONModel, Filter, FilterOperator, MessageBox, PersonalizableInfo) {
        "use strict";

        return Controller.extend("docexchangeui.controller.POList", {
            onInit: function () {
                this.getRouter().getRoute("RouteList").attachPatternMatched(this._onObjectMatched, this);
            },

            getRouter: function () {
                return UIComponent.getRouterFor(this);
            },

            _onObjectMatched: function (oEvent) {
                var oInvoiceModel = new JSONModel();
                this.getView().setModel(oInvoiceModel, "invoiceModel");
                var oViewModel = new JSONModel({
                    visible: false
                });
                this.getView().setModel(oViewModel, "viewModel");
                this.oSmartVariantManagement = this.getView().byId("svm");
                this.oFilterBar = this.getView().byId("filterbar");
                var oPersInfo = new PersonalizableInfo({
                    type: "filterBar",
                    keyName: "persistencyKey",
                    dataSource: "",
                    control: this.oFilterBar
                });
                this.oSmartVariantManagement.addPersonalizableControl(oPersInfo);
                this.oSmartVariantManagement.initialise(function () { }, this.oFilterBar);
                this.getView().byId("idSmartTable").getItems()[1].removeSelections(true);
                if (this.getView().byId("idIconTabBar").getSelectedKey() === 'Invoice') {
                    this._getInvoicesList();
                }
            },

            onTabSelect: function (oEvent) {
                var sKey = oEvent.getParameter("key");
                if (sKey === "Invoice") {
                    this._getInvoicesList();
                }
            },

            _getInvoicesList: function () {
                var sVendorNo = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
                var oVendorFilter = new Filter("supplierNo", FilterOperator.EQ, sVendorNo);
                this.getView().setBusy(true);
                this.getView().getModel("ZMM_INVOICE_SRV").read("/vendorInvSet", {
                    filters: [oVendorFilter],
                    success: function (oData) {
                        this.getView().getModel("invoiceModel").setData(oData);
                        this.getView().setBusy(false);
                    }.bind(this),
                    error: function (oErr) {
                        var oErr = oErr;
                        this.getView().setBusy(false);
                    }.bind(this)
                });
            },

            onCreate: function () {
                //this.getView().setBusy(true);
                var oItem = this.getView().byId("idSmartTable").getItems()[1].getSelectedItem();
                if (oItem) {
                    var sVendorNo = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
                    var sPONumber = oItem.getBindingContext().getObject().orderNumber;
                    var oRestModel = this.getView().getModel("rest");
                    var oPoFilter = new Filter("poNumber", FilterOperator.EQ, sPONumber);
                    var oVendorFilter = new Filter("vendorCode", FilterOperator.EQ, sVendorNo);
                    var oWorkflowCompletionTypeFilter = new Filter("workflowType", FilterOperator.EQ, "workflowCompletion");
                    var oWorkflowReadinessTypeFilter = new Filter("workflowType", FilterOperator.EQ, "materialRediness");
                    var oWorkflowTypeFilter = new Filter({
                        filters: [oWorkflowCompletionTypeFilter, oWorkflowReadinessTypeFilter],
                        and: false
                    });
                    oRestModel.read("/WorkflowDocument", {
                        filters: [oPoFilter, oWorkflowTypeFilter, oVendorFilter],
                        success: function (oData) {
                            var oData = oData;
                        }.bind(this),
                        error: function (oErr) {
                            var oErr = oErr;
                        }.bind(this)
                    });
                    // var oModel = this.getView().getModel();
                    // Promise.all([new Promise(function (resolve, reject) {
                    //     oRestModel.read("/WorkflowDocument", {
                    //         //groupId: "myGroupId",
                    //         filters: [oPoFilter, oWorkflowTypeFilter, oVendorFilter],
                    //         success: function (oData) {
                    //             resolve(oData);
                    //         }.bind(this),
                    //         error: function (oErr) {
                    //             var oErr = oErr;
                    //         }.bind(this)
                    //     });
                    // }.bind(this)),
                    // new Promise(function (resolve, reject) {
                    //     oModel.read("/vendorMappingSet(anId='AN01682282150',poNo='6000005891')", {
                    //         success: function (oData) {
                    //             resolve(oData);
                    //         }.bind(this),
                    //         error: function (oErr) {
                    //             var oErr = oErr;
                    //         }.bind(this)
                    //     });
                    // }.bind(this))

                    // ]).then(function(aResults){
                    //     this.getView().setBusy(false);
                    //     if(aResults[0].results[0].status === "APPROVED" && aResults[0].results[1].status === "APPROVED"){
                    //         this.getRouter().navTo("Detail", {
                    //             PoNo: sPONumber,
                    //             screenType: 'CreateInvoice'
                    //         });
                    //     }else {
                    //         MessageBox.error("Workflow Documents are not Approved");
                    //     }
                    // }.bind(this));
                    // new Promise(function (resolve, reject) {
                    //     oRestModel.read("/WorkflowDocument", {
                    //         //groupId: "myGroupId",
                    //         filters: [oPoFilter, oWorkflowTypeFilter],
                    //         success: function (oData) {
                    //             resolve(oData);
                    //         }.bind(this),
                    //         error: function (oErr) {
                    //             var oErr = oErr;
                    //         }.bind(this)
                    //     });
                    // }.bind(this)).then(function (oData) {
                    //     if(oData.results[0].status === "APPROVED" && oData.results[1].status === "APPROVED"){
                    //         this.getRouter().navTo("Detail", {
                    //             PoNo: sPONumber,
                    //             screenType: 'CreateInvoice'
                    //         });
                    //     }else {
                    //         MessageBox.error("Workflow Documents are not Approved");
                    //     }
                    // }.bind(this));
                    this.getRouter().navTo("Detail", {
                        PoNo: sPONumber,
                        screenType: 'CreateInvoice'
                    });
                } else {
                    this.getView().setBusy(false);
                    MessageBox.error("Please Select the PO from the PO List");
                }

            },

            onPOItemSelect: function (oEvent) {
                var oBindingContext = oEvent.getParameter("listItem").getBindingContext().getObject();
                if (oBindingContext.copySupplier === "X") {
                    this.getView().getModel("viewModel").setProperty("/visible", true);
                } else {
                    this.getView().getModel("viewModel").setProperty("/visible", false);
                }
            },

            onItemPress: function (oEvent) {
                var oBindingContext = oEvent.getParameter("listItem").getBindingContext().getObject();
                this.getRouter().navTo("Detail", {
                    PoNo: oBindingContext.orderNumber,
                    screenType: 'PODetail'
                });
            },

            onStatusClick: function (oEvent) {
                this.getView().setBusy(true);
                var oContext = oEvent.getSource().getBindingContext("invoiceModel").getObject();
                var sInvoiceNo = oContext.InvNumber;
                var sRegistrationId = oContext.regId;
                var sPoNumber = oContext.PoNumber;
                var oModel = this.getOwnerComponent().getModel("ZMM_INVOICE_SRV");
                var sPath = oModel.createKey("/invoicePaymentDetSet", {
                    "poNumber": sPoNumber,
                    "registrationId": sRegistrationId,
                    "invoiceNo": sInvoiceNo
                });

                new Promise(function (resolve, reject) {
                    oModel.read(sPath, {
                        success: function (oData) {
                            var oPaymentDetails = new JSONModel(oData);
                            this.getView().setModel(oPaymentDetails, "paymentDetails");
                            resolve(oData);
                        }.bind(this),
                        error: function (oError) {
                            this.getView().setBusy(false);
                            var sErrorMessage = JSON.parse(oError.responseText).error.message.value;
                            sap.m.MessageBox.error("Error retrieving data: " + sErrorMessage);
                            console.log(sErrorMessage);
                        }
                    });
                }.bind(this)).then(function (oData) {
                    if (!this._oDialog) {
                        this._oDialog = sap.ui.xmlfragment("docexchangeui.fragments.PaymentDetails", this);
                        this.getView().addDependent(this._oDialog);
                    }
                    this._oDialog.open();
                    this.getView().setBusy(false);
                }.bind(this));
            },

            onClosePaymentDetailDialog: function () {
                this._oDialog.close();
            },

            onInvoicePress: function (oEvent) {
                var oBindingContext = oEvent.getParameter("listItem").getBindingContext("invoiceModel").getObject();
                this.getRouter().navTo("Detail", {
                    PoNo: oBindingContext.PoNumber,
                    screenType: 'InvoiceDetail',
                    InvoiceNo: oBindingContext.InvNumber,
                    RegID: oBindingContext.regId
                });
            },

            onBeforeRebindTable: function (oEvent) {
                if (this.getOwnerComponent().getModel("userModel")) {
                    var oBindingParams = oEvent.getParameter("bindingParams"), oFilter, oVendorFilter,
                        sVendorNo = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
                    var sOrderNo = this.getView().byId("idFilterOrderNo").getValue();
                    if (sOrderNo) {
                        oVendorFilter = new Filter("vendorNo", FilterOperator.EQ, sVendorNo);
                        oFilter = new Filter("orderNumber", FilterOperator.EQ, sOrderNo);
                        var oFilterAll = new Filter({
                            filters: [oVendorFilter, oFilter],
                            and: true
                        });
                        oBindingParams.filters.push(oFilterAll);
                    } else {
                        var oVendorFilter = new Filter("vendorNo", FilterOperator.EQ, sVendorNo);
                        oBindingParams.filters.push(oVendorFilter);
                    }
                }
            },
        });
    });
