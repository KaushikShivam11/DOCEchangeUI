sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/FileSizeFormat",
    "sap/ui/Device",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "sap/m/upload/UploadSetItem",
    "sap/ui/core/Item",
    "sap/m/MessageBox",
    "sap/ui/core/UIComponent",
    "sap/ui/core/Fragment",
    "sap/m/Token",
    "sap/ui/core/CustomData",
    "../model/formatter"
], function (Controller, JSONModel, FileSizeFormat, Device, Filter, FilterOperator,
    History, MessageToast, UploadSetItem, Item, MessageBox, UIComponent, Fragment, Token, CustomData, formatter) {
    "use strict";
    return Controller.extend("docexchangeui.controller.CreateInvoice", {
        formatter: formatter,
        onInit: function () {
            this.getRouter().getRoute("CreateInvoice").attachPatternMatched(this._onObjectMatched, this);
        },

        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },

        _onObjectMatched: function (oEvent) {
            var oDetailModel = new JSONModel();
            this.getView().setModel(oDetailModel, "detailModel");
            var oInvoiceModel = new JSONModel();
            this.getView().setModel(oInvoiceModel, "invoiceModel");
            var oSelectedItemsModel = new JSONModel({ FinalItemModel: [] });
            this.getView().setModel(oSelectedItemsModel, "selectedItemsModel");
            var oAttachment = new JSONModel();
            this.getView().setModel(oAttachment, "Attachments");
            var oRestDocModel = new JSONModel();
            this.getView().setModel(oRestDocModel, "restDocModel");
            var oScreenModel = new JSONModel({
                "display": ""
            });
            this.getView().setModel(oScreenModel, "screenTypeModel");
            var oFileModel = new JSONModel();
            this.getView().setModel(oFileModel, "fileModel");
            this.sPoNo = oEvent.getParameter("arguments").PoNo;
            var sScreenType = oEvent.getParameter("arguments").screenType;
            this.getView().getModel("screenTypeModel").setProperty("/display", sScreenType);
            var oModel = this.getView().getModel();
            var sVendorNo = this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode");
            var oDocListData = {
                "DocList": [{
                    "title": "BL Copy",
                    "completed": false
                },
                {
                    "title": "Invoice Copy",
                    "completed": false
                },
                {
                    "title": "BOE Copy",
                    "completed": false
                },
                {
                    "title": "CP Copy",
                    "completed": false
                },
                {
                    "title": "Contract Copy",
                    "completed": false
                },
                {
                    "title": "Form 10F",
                    "completed": false
                },
                {
                    "title": "TRC",
                    "completed": false
                },
                {
                    "title": "No PE Certificate",
                    "completed": false
                },
                {
                    "title": "Others Copy",
                    "completed": false
                }
                ],
                "completedCount": 1
            };
            var oDocListModel = new JSONModel(oDocListData);
            this.getView().setModel(oDocListModel, "docListModel");
            var sPath = oModel.createKey("PODetailsSet", {
                orderNumber: this.sPoNo,
                vendorNo: sVendorNo
            });
            oModel.read("/" + sPath, {
                success: function (oData) {
                    this.getView().getModel("detailModel").setData(oData);
                    // Create a JSONModel with the item data
                    var oPOItemModel = new JSONModel({ FinalItemModel: oData.POLineItemsSet.results });
                    // Set the item data model to the view table 1
                    this.getView().setModel(oPOItemModel, "SelectionItemModel");

                }.bind(this),
                error: function (oError) {

                }.bind(this),
                urlParameters: {
                    $expand: 'POLineItemsSet,POVendorsSet,partnerFunctionsSet'
                }
            });
        },

        onInvoiceValueChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onInvoiceNumberChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onInvoiceDateChange: function (oEvent) {
            oEvent.getSource().setValueState("None");
            oEvent.getSource().setValueStateText("");
        },

        onSelectionChange: function (oEvent) {
            var oTable = oEvent.getSource();
            var aSelectedItems = oTable.getSelectedItems();
            var aSelectedContexts = aSelectedItems.map(function (item) {

                var i = item.getBindingContext("SelectionItemModel").getObject();
                i.OrginalQty = Number(i.lineItemQuant);
                return i;
            });


            // Update the selectedItemsModel with the selected items

            aSelectedContexts.forEach(item => {

                if (!item.TotalValue) { // Convert unitPrice and lineItemQuant to numbers and multiply
                    let amount = parseFloat(item.unitPrice.trim()) * parseFloat(item.lineItemQuant.trim());
                    // Assign the calculated amount to the TotalValue field
                    item.lineItemQuant = Number(item.lineItemQuant.trim())
                    item.TotalValue = amount.toString();

                    item.cgstValue = parseFloat((parseFloat(amount.toString()) * (parseFloat(item.CgstPercent) / 100)).toFixed(4));
                    item.sgstValue = parseFloat((parseFloat(amount.toString()) * (parseFloat(item.sgstPercent) / 100)).toFixed(4));

                }

            });


            this.getView().getModel("selectedItemsModel").setData({ FinalItemModel: aSelectedContexts });
            this.calculateOverallTotal();
        },

        onQuantityChange: function (oEvent) { // Get the event source which is the input field
            var oInput = oEvent.getSource();
            // Get the current row context
            var oContext = oInput.getBindingContext("selectedItemsModel");
            // Retrieve the new quantity value entered by the user and original quantity
            var iNewQuantity = parseInt(oInput.getValue(), 10);
            // Validate the new quantity
            if (isNaN(iNewQuantity) || iNewQuantity <= 0 || iNewQuantity > oContext.getProperty("OrginalQty") || iNewQuantity.toString() !== oInput.getValue()) { // If validation fails, set input field to Error state and return
                oInput.setValueState(sap.ui.core.ValueState.Error);
                oInput.setValueStateText("Invalid quantity. Must be a positive integer and cannot exceed original quantity.");
                this.getModel("objectView").setProperty("/enabled", false);
                return;
            } else { // If validation passes, reset input field state to None
                oInput.setValueState(sap.ui.core.ValueState.None);
                //this.getModel("objectView").setProperty("/enabled", true);
                // Proceed with total value calculation since validation passed
                if(this.getView().getModel("detailModel").getProperty("/copySupplier") === 'X'){
                    var fUnitPrice = parseFloat(oContext.getProperty("amount"));
                }else{
                    var fUnitPrice = parseFloat(oContext.getProperty("unitPrice"));
                }
                var fNewTotalValue = parseFloat((iNewQuantity * fUnitPrice).toFixed(4));
                let cgstValue = parseFloat((parseFloat(fNewTotalValue) * (parseFloat(oContext.getProperty("CgstPercent")) / 100)).toFixed(2));
                let sgstValue = parseFloat((parseFloat(fNewTotalValue) * (parseFloat(oContext.getProperty("sgstPercent")) / 100)).toFixed(2));


                // Update the model with the new total value,cgst,sgst values
                oContext.getModel().setProperty(oContext.getPath() + "/TotalValue", fNewTotalValue.toString());
                oContext.getModel().setProperty(oContext.getPath() + "/cgstValue", cgstValue);
                oContext.getModel().setProperty(oContext.getPath() + "/sgstValue", sgstValue);

                this.calculateOverallTotal();
            }


        },

        calculateOverallTotal: function () {
            var oModel = this.getView().getModel("selectedItemsModel");
            var aLineItems = oModel.getProperty("/FinalItemModel");

            // Initialize total values
            var fOverallTotal = 0,
                fOverallTotalCGST = 0,
                fOverallTotalSGST = 0;

            // Use a single loop to calculate totals
            aLineItems.forEach(function (currentItem) { // Calculate TotalValue
                var fTotalValue = parseFloat(currentItem.TotalValue);
                if (isNaN(fTotalValue)) {
                    fTotalValue = 0;
                }
                fOverallTotal += fTotalValue;

                // Calculate CGST
                var fTotalValueCGST = parseFloat(currentItem.cgstValue);
                if (isNaN(fTotalValueCGST)) {
                    fTotalValueCGST = 0;
                }
                fOverallTotalCGST += fTotalValueCGST;

                // Calculate SGST
                var fTotalValueSGST = parseFloat(currentItem.sgstValue);
                if (isNaN(fTotalValueSGST)) {
                    fTotalValueSGST = 0;
                }
                fOverallTotalSGST += fTotalValueSGST;
            });

            // Calculate Grand Total
            let GrandTotal = parseFloat((fOverallTotal + fOverallTotalCGST + fOverallTotalSGST).toFixed(4));


            // Set the calculated totals in the model
            var CalculatedTotalModel = new JSONModel({ total: fOverallTotal, total_cgst: fOverallTotalCGST, total_sgst: fOverallTotalSGST, Grand_total: GrandTotal });
            this.getView().setModel(CalculatedTotalModel, "TotalCostDataModel");


            // console.log("Overall Total:", fOverallTotal);
            this.setAmtInputState(GrandTotal, "ITM");
            return fOverallTotal;
        },

        setAmtInputState: function (Amt, From) {
            var HeaderAmount;
            var ItemAmount;
            if (HeaderAmount > ItemAmount || HeaderAmount <= 0) {
                this.getView().byId("AdvPayValue").setValueState(sap.ui.core.ValueState.Error);
                this.getView().byId("AdvPayValue").setValueStateText("Header amount can't be greater then Item Level Amount or (Zero/Empty) to any negative.");
                this.getModel("objectView").setProperty("/enabled", false);
            } else {
                this.getModel("objectView").setProperty("/enabled", true);
            }
        },

        onBeforeUploadStarts: function () {
            if (!this._oDocListDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.documentList",
                    controller: this
                }).then(function (_oDocListDialog) {
                    this._oDocListDialog = _oDocListDialog;
                    this.getView().addDependent(this._oDocListDialog);
                    this._oDocListDialog.open();
                }.bind(this));
            } else {
                this._oDocListDialog.open();
            }
        },

        onCloseDocListDialog: function () {
            this._oDocListDialog.close();
        },

        onDocListPress: function () {
            if (!this._oDocListDialog) {
                Fragment.load({
                    name: "docexchangeui.fragments.documentList",
                    controller: this
                }).then(function (_oDocListDialog) {
                    this._oDocListDialog = _oDocListDialog;
                    this.getView().addDependent(this._oDocListDialog);
                    this._oDocListDialog.open();
                }.bind(this));
            } else {
                this._oDocListDialog.open();
            }
        },

        onSubmitInvoice: function () {
            this.getView().setBusy(true);
            var aInvoiceLineItems = this.getView().byId("idPRItem2Table").getItems();
            if (!this.getView().byId("idInvoiceNumberInput").getValue()) {
                this.getView().setBusy(false);
                MessageBox.error("Please enter the Invoice Number");
                this.getView().byId("idInvoiceNumberInput").setValueState("Error");
                this.getView().byId("idInvoiceNumberInput").setValueStateText("Please enter the Invoice Number");
                return;
            }
            if (!this.getView().byId("idInvoiceValue").getValue()) {
                this.getView().setBusy(false);
                MessageBox.error("Please enter the Invoice Value");
                this.getView().byId("idInvoiceValue").setValueState("Error");
                this.getView().byId("idInvoiceValue").setValueStateText("Please enter the Invoice Value");
                return;
            }
            if (!this.getView().byId("idInvoiceDate").getValue()) {
                this.getView().setBusy(false);
                MessageBox.error("Please select the Invoice Date");
                this.getView().byId("idInvoiceDate").setValueState("Error");
                this.getView().byId("idInvoiceDate").setValueStateText("Please select the Invoice Date");
                return;
            }
            var aIncompleteFiles = this.getView().byId("idAttachments").getIncompleteItems();
            if (aInvoiceLineItems.length === 0) {
                this.getView().setBusy(false);
                MessageBox.error("Please select the Items from PO Table");
                return;
            }
            var iPointer = 1;
            Promise.all(
                aIncompleteFiles.map(function (curr) {
                    return new Promise(function (resolve, reject) {
                        const fileReader = new FileReader();

                        fileReader.onload = function (file) {
                            var ofileObject = {
                                "attachment": file.target.result.split(',')[1],
                                "Name": curr.getFileObject().name,
                                "PoNumber": this.sPoNo,
                                "filetype": curr.getFileObject().type,
                                "attachmentNo": (iPointer++).toString()
                            }
                            resolve(ofileObject);
                        }.bind(this);

                        fileReader.onerror = (error) => reject(error);

                        fileReader.readAsDataURL(curr.getFileObject());
                    }.bind(this));
                }.bind(this))
            ).then(function (base64Files) {
                var aBase64Files = base64Files;
                var oDetailModelData = this.getView().getModel("detailModel").getData();
                var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyyMMdd" });
                var oDateNonFormatted = this.getView().byId("idInvoiceDate").getDateValue();
                var sDateFormatted = oDateFormat.format(oDateNonFormatted);
                var oInvoicePayload = {
                    "PoNumber": this.sPoNo,
                    "contractNumber": oDetailModelData.contractNo,
                    "VendorName": oDetailModelData.vendorName,
                    "VendorGSTIN": oDetailModelData.vendorGstin,
                    "invoiceNo": this.getView().byId("idInvoiceNumberInput").getValue(),
                    "invoiceDate": sDateFormatted,
                    "invoiceValue": this.getView().byId("idInvoiceValue").getValue(),
                    "curr": oDetailModelData.curr,
                    "email": oDetailModelData.email,
                    "supplierNo": this.getOwnerComponent().getModel("userModel").getProperty("/vendorCode")
                }
                oInvoicePayload.InvoiceAttachmentSet = aBase64Files;
                var aInvoiceLineItemsPaylod = aInvoiceLineItems.map(function(curr, ind){
                    var oBindingContext = curr.getBindingContext("selectedItemsModel").getObject();
                    var oInvoiceLineItemsPaylod =
                    {
                        "itemNo": oBindingContext.itemNo,
                        "itemDesc": oBindingContext.itemDesc,
                        "itemCondDesc": oBindingContext.itemCondDesc,
                        "plant": oBindingContext.plant,
                        "lineItemQuant": this.getView().byId("idPRItem2Table").getItems()[ind].getCells()[5].getValue(),
                        "unitPrice": oBindingContext.unitPrice,
                        "TotalValue": oBindingContext.TotalValue,
                        "CgstPercent": oBindingContext.CgstPercent,
                        "sgstPercent": oBindingContext.sgstPercent,
                        "cgstValue": oBindingContext.cgstValue.toString(),
                        "sgstValue": oBindingContext.sgstValue.toString(),
                        "orderNumber": oBindingContext.orderNumber,
                        "condType" : oBindingContext.condType,
                        "amount" : oBindingContext.amount,
                        "conditionValue" : oBindingContext.conditionValue
                    }
                    return oInvoiceLineItemsPaylod;
                }.bind(this));

                oInvoicePayload.InvoiceLineItemSet = aInvoiceLineItemsPaylod;
                this.getView().getModel("ZMM_INVOICE_SRV").create("/InvoiceRequestSet", oInvoicePayload, {
                    success: function (oData, oRes) {
                        var sMsg = `Invoice Created with Reg ID ${oData.regID}`
                        MessageBox.success(sMsg);
                        this.getView().byId("idAttachments").destroyIncompleteItems();
                        this.getView().byId("idInvoiceNumberInput").setValue("");
                        this.getView().byId("idInvoiceValue").setValue("");
                        this.getView().byId("idInvoiceDate").setValue("");
                        this.getView().setBusy(false);
                    }.bind(this),
                    error: function (oErr) {
                        var oErr = oErr;
                        this.getView().byId("idAttachments").destroyIncompleteItems();
                        this.getView().setBusy(false);
                        MessageBox.error("");
                    }
                });

            }.bind(this));


        }

    });

});
